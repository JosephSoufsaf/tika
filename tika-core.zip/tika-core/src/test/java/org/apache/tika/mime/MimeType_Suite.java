/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.tika.mime;

import org.junit.platform.runner.JUnitPlatform;
import org.junit.platform.suite.api.SelectClasses;
import org.junit.runner.RunWith;

@RunWith(value = JUnitPlatform.class)
@SelectClasses(value = { MimeType_compareTo_22_0_Test.class, MimeType_equals_23_0_Test.class, MimeType_hashCode_24_0_Test.class, MimeType_hasMagic_17_0_Test.class, MimeType_isValid_0_0_Test.class, MimeType_matchesMagic_18_1_Test.class, MimeType_matches_19_0_Test.class, MimeType_toString_25_0_Test.class })
public class MimeType_Suite {
}
