/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.tika.metadata.filter;

import java.util.List;

import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.ParseContext;

/**
 * Base class for iterating a call to {@link #filter(Metadata)} on a list
 * of metadata objects. This should be used on context-free metadata filters that
 * do not require knowledge of more than a single metadata object at a time
 */
public abstract class MetadataFilterBase extends MetadataFilter {

    @Override
    protected void doFilter(List<Metadata> metadataList, ParseContext parseContext)
            throws TikaException {
        for (Metadata m : metadataList) {
            filter(m);
        }
    }

    protected abstract void filter(Metadata metadata);
}
